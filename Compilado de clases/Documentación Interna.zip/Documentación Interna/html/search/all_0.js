var searchData=
[
  ['ampliar',['Ampliar',['../class_ampliar.html',1,'']]]
];
